public class Main {
    public static void main(String[] args) {
        int n = 10;
        System.out.println("Fibonacci de " + n + " é " + fibonacciIterativo(n));
        System.out.println("Fibonacci de " + n + " é " + fibonacciRecursivo(n));
    }

    public static int fibonacciIterativo(int n) {
        if (n < 2) {
            return n;
        }
        int anterior = 0;
        int atual = 1;
        for (int i = 2; i <= n; i++) {
            int proximo = anterior + atual;
            anterior = atual;
            atual = proximo;
        }
        return atual;
    }

    public static int fibonacciRecursivo(int n) {
        if (n < 2) {
            return n;
        }
        return fibonacciRecursivo(n - 1) + fibonacciRecursivo(n - 2);
    }
}
