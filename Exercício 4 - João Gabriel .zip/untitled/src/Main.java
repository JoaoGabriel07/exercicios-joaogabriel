public class Main {
    public static void main(String[] args) {
        int n = 5;
        System.out.println("Fatorial de " + n + " é " + fatorialIterativo(n));
        System.out.println("Fatorial de " + n + " é " + fatorialRecursivo(n));
    }

    public static int fatorialIterativo(int n) {
        int resultado = 1;
        for (int i = 2; i <= n; i++) {
            resultado *= i;
        }
        return resultado;
    }

    public static int fatorialRecursivo(int n) {
        if (n == 0) {
            return 1;
        }
        return n * fatorialRecursivo(n - 1);
    }
}
