import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Digite o tamanho do array: ");
        int tamanho = input.nextInt();
        int[] array = new int[tamanho];
        for (int i = 0; i < tamanho; i++) {
            System.out.print("Digite o " + (i + 1) + "º número: ");
            array[i] = input.nextInt();
        }
        int maior = array[0];
        for (int i = 1; i < tamanho; i++) {
            if (array[i] > maior) {
                maior = array[i];
            }
        }
        System.out.println("O maior valor do array é: " + maior);
    }
}